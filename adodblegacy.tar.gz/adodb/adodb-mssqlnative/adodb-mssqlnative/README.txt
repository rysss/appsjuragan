Hi,

Place the following files in adodb 4.99 or 5.05 directories:

	adodb/data-dict/datadict-mssqlnative.inc.php
	adodb/drivers/adodb-mssqlnative.inc.php
	adodb/perf/perf-mssqlnative.inc.php 
	
Download adodb from:

  http://sourceforge.net/project/showfiles.php?group_id=42718

Download mssqlnative extension from

  http://www.microsoft.com/downloads/details.aspx?FamilyId=61BF87E0-D031-466B-B09A-6597C21A2E2A&displaylang=en
  

Regards, John Lim
jlim#natsoft.com


===== ENCLOSED IS LETTER FROM GARRETT SERACK, M'soft: ================

Adodb
John Lim
http://adodb.sourceforge.net/

Dear John,
 
Attached please find a copy of our submission files:

	datadict-mssqlnative.inc.php.diff
	adodb-mssqlnative.inc.php.diff
	perf-mssqlnative.inc.php.diff
 
For purposes of this submission, and in light of the nature of these particular
.diff files submissions, Microsoft is not claiming any copyrights or patentable
subject matter in the .diff files, and therefore, no intellectual property 
license rights or restrictions are being provided by Microsoft with respect to
the files.
 
There are NO WARRANTIES OF ANY KIND with respect to the files or any resulting 
file(s) that are created by applying these .diff files to any other files. 
Microsoft further reserves all of its intellectual property rights with regard 
to such resulting file in combination with any other software.  
 
Regards, 

Garrett Serack
Open Source Community Developer
Microsoft Corporation
garretts#microsoft.com

